/**
 * @file student.c
 * @author Elite Lu (lue13@mcmaster.ca)
 * @brief Operations involving students such as adding marks to their list of grades, calculating average, printing a student's information, and student generation
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Adds the student's grade to the list of their grades
 * 
 * @param student The specified student of data type Student
 * @param grade The mark that was generated
 * @return void
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  // Creates space for one grade value in the list if there is only one mark
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); 
  else 
  {
    student->grades = 
      // Adds more space if the student has more than one mark 
      realloc(student->grades, sizeof(double) * student->num_grades); 
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Generates the average of the student by addng all the values and dividing by the number of marks
 * 
 * @param student The designated student that will have their average calculated
 * @return double 
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  // Adds every grade the student has, calculate the sum, and divide by the number of marks
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i]; 
  return total / ((double) student->num_grades); 
}

/**
 * @brief Prints out the student information
 * 
 * @param student The designated student that will have their information printed 
 * @return void
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // Prints the student ID by printing character by character
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]); 
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}
/**
 * @brief Generates a random student with a specified number of marks and returns the random student
 * 
 * @param grades The number of grades that the student gets 
 * @return Student
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));
  // Gets a random first name
  strcpy(new_student->first_name, first_names[rand() % 24]);
  // Gets a random last name 
  strcpy(new_student->last_name, last_names[rand() % 24]); 

  // Generates a random student ID
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48); 
  new_student->id[10] = '\0';

  // Adds a random grade value to the student's record
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75))); 
  }

  return new_student;
}