/**
 * @file student.h
 * @author Elite Lu (lue13@mcmaster.ca)
 * @brief Data structure for students
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief The data structure for the student
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< student first name */
  char last_name[50]; /**< student last name */
  char id[11]; /**< student ID */
  double *grades; /**< list of the student's grades */
  int num_grades; /**< number of generated grades */
} Student;

void add_grade(Student *student, double grade); 
double average(Student *student); 
void print_student(Student *student); 
Student* generate_random_student(int grades);
