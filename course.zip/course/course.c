/**
 * @file course.c
 * @author Elite Lu (lue13@mcmaster.ca)
 * @brief Course operations such as enrollment, printing courses, determining the best student, and the students that are passing
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief Enrolls a student into the course
 * 
 * @param course The course that the student is enrolling in
 * @param student The student that is enrolling in the course
 * @return void
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    // Allocates space for one student
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      // Reallocates more storage for multiple students enrolling in the course
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * Prints the course and the students that are in the course
 * 
 * @param course The designated course that will have its name, course code, and students printed
 * @return void
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // Print out each student in the course
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Determines the best student in the class
 * 
 * @param course The designated course used for determining the best student in
 * @return Student* The best student in the designated course
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  // Cycles through every student and finds the student with the highest mark
  for (int i = 1; i < course->total_students; i++) 
  {
    student_average = average(&course->students[i]);
    // Checks if the student has a higher average than the previously stored student
    if (student_average > max_average) 
    {
      // Overwrites if the current student has a higher average and changes the current stored average and student
      max_average = student_average; 
      student = &course->students[i]; 
    }   
  }

  return student;
}

/**
 * @brief Determines if the student is passing
 * 
 * @param course The designated course
 * @param total_passing The number of students passing the course
 * @return The student that was checked for whether or not they were passing
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // Determines the number of students passing by checking if their average is above or equal to 50
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  // Adds the student into the list of passing students if their mark is higher than or equal to 50
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}