/**
 * @mainpage Final Assignment Question 1 Documentation
 * @file main.c
 * @author Elite Lu (lue13@mcmaster.ca)
 * @brief Main function 
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief This is information on generating and checking the number of students passed for a specific course
 * @return int
 */
int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course)); // Custom data type for courses 
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8)); // Creates 8 different students
  
  print_course(MATH101);

  Student *student; // Custom data type for student
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing); // Checks if a student has passed 
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]); // Prints out the students that are passing 
  
  return 0;
}