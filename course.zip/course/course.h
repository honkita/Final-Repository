/**
 * @file course.h
 * @author Elite Lu (you@domain.com)
 * @brief Data structure for courses
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
 
/**
 * @brief Data structure for courses
 * 
 */
typedef struct _course 
{
  char name[100]; /**< course name */
  char code[10]; /**< course code */
  Student *students; /**< students enrolled */
  int total_students; /**< number of students enrolled */
} Course;

void enroll_student(Course *course, Student *student); 
void print_course(Course *course); 
Student *top_student(Course* course); 
Student *passing(Course* course, int *total_passing); 


